var fruit1,fruit1i,fruit2i,fruit3i,fruit4i,alnie1,alnie2,sword,swordimg,
 fruitgroup   
function preload(){
  
  fruit1i=loadImage("fruit1.png")
  fruit2i=loadImage("fruit2.png")
  fruit3i=loadImage("fruit3.png")
  fruit4i=loadImage("fruit4.png")
 alnie1=loadImage("alien1.png")
  alnie2=loadImage("alien2.png")
  swordimg=loadImage("sword.png")
}

function setup(){
  
  createCanvas(600,400)
  sword=createSprite(300,200,40,50)
  sword.addImage(swordimg)
  sword.scale=0.5
  fruitgroup=createGroup()
  
}

function draw(){
background("lightblue")
  
  sword.x=mouseX
  sword.y=mouseY
  if(fruitgroup.isTouching(sword)){
     fruitgroup.destroyEach()
     
     
     }
  
  fruits()
  
  aliens()
  
drawSprites()  

}

function fruits(){
  if(frameCount%70==0){
    
var a=random(0,600)
 var b=random(0,400)   
     fruit=createSprite(600,b,20,40) 
    fruitgroup.add(fruit)
    fruit.velocityX=-8
   fruit.scale=0.2
    var c= Math.round(random(1,2))
   switch(c){ 
          case 1:fruit.addImage(fruit1i)
    break;
     case 2:fruit.addImage(fruit2i)
      break;
      
     }
  }
}
function aliens(){ 
  if(frameCount%40==0){
  
  var a=random(0,600)
  var alien=createSprite(a,0,30,50)
    alien.velocityY=8
    var d=Math.round(random(1,2))
    switch(d){
           case 1:alien.addImage(alnie1)
      break;
      case 2:alien.addImage(alnie2)
      break;
           
           }
  }
}